import React from 'react'

function Greet(){
    return <h1>Hello Shivi!!</h1>
}
export default Greet